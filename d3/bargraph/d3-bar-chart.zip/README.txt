A Pen created at CodePen.io. You can find this one at https://codepen.io/anon/pen/Oxgxgq.

 A minimal demonstration of how to create an HTML bar chart with D3. Fork this template to create your own chart.